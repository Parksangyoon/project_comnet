from django.db import models
from .SkillList import SkillList
# Create your models here.
class player1:
    hp=100
    mp=100
    Hero=0	#선택한 캐릭터의 id(is = 1 bi = 2 pz = 3)
    Position = [0, 0]
    Skill_A = []
    Skill_B = []
    Skill_C = []
    Skill_D = []
    SkillBook = SkillList()
    CardSelection = [0, 0, 0]

    def getSkillandPos (self): # 처음 생성시 데이터를 입력해주는 함수
        
        self.Position = [0, 1] # player1은 (0,1)위치에서 시작하도록 한다.
        
       
        if(self.Hero == 1):     # n번 hero를 골랐다면 Transport_Skill_Hero(n)함수가 실행되도록 한다.
            Transport_Skill_Hero1 (self, self.SkillBook) #각 hero마다 가지고있는 skill의 종류가 다르다.
        elif(self.Hero == 2):
            Transport_Skill_Hero2 (self, self.SkillBook)
        elif(self.Hero == 3):
            Transport_Skill_Hero3 (self, self.SkillBook)
    
class player2:
    hp=100
    mp=100
    Hero=0
    Position = [0, 0]
    Skill_A = []
    Skill_B = []
    Skill_C = []
    Skill_D = []
    SkillBook = SkillList()
    CardSelection = [0, 0, 0]

    def getSkillandPos (self):        # 처음 생성시 데이터를 입력해주는 함수
        
        self.Position = [4, 2] # player2는 (4,2)위치에서 시작하도록 한다.
       
        if(self.Hero == 1):     # n번 hero를 골랐다면 Transport_Skill_Hero(n)함수가 실행되도록 한다.
            Transport_Skill_Hero1 (self, self.SkillBook) #각 hero마다 가지고있는 skill의 종류가 다르다.
        elif(self.Hero == 2):
            Transport_Skill_Hero2 (self, self.SkillBook)
        elif(self.Hero == 3):
            Transport_Skill_Hero3 (self, self.SkillBook)
    
def Transport_Skill_Hero1 (Player, SkillList):  # Hero 1이 가지고 있는 스킬을 0,3,6,7번으로 지정한다.
    Player.Skill_A = SkillList.getskillnum(0)
    Player.Skill_B = SkillList.getskillnum(3)
    Player.Skill_C = SkillList.getskillnum(6)
    Player.Skill_D = SkillList.getskillnum(7)

def Transport_Skill_Hero2 (Player, SkillList):  # Hero 1이 가지고 있는 스킬을 0,2,5,8번으로 지정한다.
    Player.Skill_A = SkillList.getskillnum(0)
    Player.Skill_B = SkillList.getskillnum(2)
    Player.Skill_C = SkillList.getskillnum(5)
    Player.Skill_D = SkillList.getskillnum(8)

def Transport_Skill_Hero3 (Player, SkillList):  # Hero 1이 가지고 있는 스킬을 0,1,4,7번으로 지정한다.
    Player.Skill_A = SkillList.getskillnum(0)
    Player.Skill_B = SkillList.getskillnum(1)
    Player.Skill_C = SkillList.getskillnum(4)
    Player.Skill_D = SkillList.getskillnum(7)