from django.shortcuts import render
from django.http import HttpResponse

from .models import player1, player2
# Create your views here.

def index(request): 
	start.start+=1
	if(start.start ==1):
		start.str="player{}".format(start.start) 
		context = {'num' : start} 
		return render(request, 'start/startscreen.html',context)
	elif(start.start ==2):
		start.str="player{}".format(start.start) 
		context = {'num' : start} 
		return render(request, 'start/startscreen.html',context)
	else:
		return
	
def selectcharacter(request):
	check = request.POST["playstart"] #플레이어 1(2)임을 알수있는 변수
	start.wait+=1
	if(check == "player1"):
		context={'num' : check}
		while(start.wait==1):
			wait=0
		return render(request, 'start/selectcharacter.html',context)

	elif(check == "player2"):
		context={'num' : check}
		return render(request, 'start/selectcharacter.html',context)

def selectcardis(request):
	check = request.POST["play"] #플레이어 1(2)임을 알수있는 변수
	if(check == "player1"):
		player1.Hero=1
		player1.getSkillandPos()

		context={'num' : check, 'SkillA' : player1.Skill_A}
		return render(request, 'start/selectcardis.html',context)

	elif(check == "player2"):
		player2.Hero=1
		player2.getSkillandPos()
		context={'num' : check , 'SkillA' : player2.Skill_A}
		return render(request, 'start/selectcardis.html',context)

def selectcardbi(request):
	check = request.POST["play"]
	if(check == "player1"):
		player1.Hero=2
		player1.getSkillandPos()
		context={'num' : check , 'SkillA' : player1.Skill_A}
		return render(request, 'start/selectcardbi.html',context)

	elif(check == "player2"):
		player2.Hero=2
		player2.getSkillandPos()
		context={'num' : check , 'SkillA' : player2.Skill_A}
		return render(request, 'start/selectcardbi.html',context)

def selectcardpz(request):
	check = request.POST["play"]
	if(check == "player1"):
		player1.Hero=3
		player1.getSkillandPos()
		context={'num' : check , 'SkillA' : player1.Skill_A}
		return render(request, 'start/selectcardpz.html',context)

	elif(check == "player2"):
		player2.Hero=3
		player2.getSkillandPos()
		context={'num' : check , 'SkillA' : player2.Skill_A}
		return render(request, 'start/selectcardpz.html',context)

class start:
	wait=0
	end=0
	start=0
	str=""