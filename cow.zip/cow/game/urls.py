from django.conf.urls import url
from . import views


urlpatterns = [
  url(r'^$', views.index),
  url(r'^selectcharacter/$', views.selectcharacter),

  url(r'^selectcardis/$', views.selectcardis),
  url(r'^selectcardbi/$', views.selectcardbi),
  url(r'^selectcardpz/$', views.selectcardpz)
]
