from django.conf.urls import url
from . import views


urlpatterns = [
  url(r'^$', views.index),
  url(r'^selectcharacter/$', views.selectcharacter),

  url(r'^selectcharacter/selectcardis/$', views.selectcardis),
  url(r'^selectcharacter/selectcardbi/$', views.selectcardbi),
  url(r'^selectcharacter/selectcardpz/$', views.selectcardpz)
]