from django.contrib import admin

from .models import player, startplayer
# Register your models here.
admin.site.register(player)
admin.site.register(startplayer)