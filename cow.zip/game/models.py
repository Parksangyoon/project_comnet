from django.db import models

# Create your models here.
class player(models.Model):
    Hp = models.IntegerField(default=100)
    Mp = models.IntegerField(default=100)
    Charactercard = models.IntegerField(default=0)
    Activecard1 = models.IntegerField(default=0)
    Activecard2 = models.IntegerField(default=0)
    Activecard3 = models.IntegerField(default=0)
    position_x = models.IntegerField(default=0)
    position_y = models.IntegerField(default=2)
    win = models.IntegerField(default=0)
    draw = models.IntegerField(default=0)
    lose = models.IntegerField(default=0)
    mynum = models.CharField(max_length=10)
    enemy = models.CharField(max_length=10)
    field = models.IntegerField(default=0)
    def _str_(self):
        return self.mynum

class startplayer(models.Model):
    play=0
    field= models.IntegerField(default=0)
    winer= models.CharField(max_length=10)
    player1 = models.CharField(max_length=10)
    player2 = models.CharField(max_length=10)
    def _str_(self):
        return self.field