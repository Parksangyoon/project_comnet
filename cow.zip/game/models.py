from django.db import models

# Create your models here.
class player(models.Model):
    player =0;
    Hp = models.IntegerField(default=100)
    Mp = models.IntegerField(default=0)
    Charactercard = models.IntegerField(default=0)
    Activecard1 = models.IntegerField(default=0)
    Activecard2 = models.IntegerField(default=0)
    Activecard3 = models.IntegerField(default=0)
    position_x = models.IntegerField(default=0)
    position_y = models.IntegerField(default=0)
    party_number = models.IntegerField(default=0)

