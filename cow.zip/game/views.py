from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
	a=Foo
	context = {'player' : a}
	
	if a.stackplayer==1:
		while a.stackplayer ==1:
			pass
		return render(request, 'start/startscreen.html', context)	
	elif a.stackplayer==2:
		while a.stackplayer ==1:
			pass
		return render(request, 'start/selectcharacter.html',context)
	else :
		a.stackplayer=1;
		return render(request, 'start/selectcardis.html',context)	  
	
	

def selectcharacter(request):
	return render(request, 'start/selectcharacter.html')

def selectcardis(request):
	return render(request, 'start/selectcardis.html')

def selectcardbi(request):
	return render(request, 'start/selectcardbi.html')

def selectcardpz(request):
	return render(request, 'start/selectcardpz.html')

class Foo:
    stackplayer=+1
