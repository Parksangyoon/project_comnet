from django.shortcuts import render
from django.http import HttpResponse

from .models import player,startplayer
# Create your views here.

def index(request):
	st.stackplayer+=1
	st.str="player{}".format(st.stackplayer)
	context = {'num' : st}
	return render(request, 'start/startscreen.html',context)	  
	
def selectcharacter(request):
	while(True):

		if(startplayer.play==0):
			startplayer.play+=1
			st.stackfield+=1

			playername = request.POST["playstart"]
			play = player(mynum=playername, field=st.stackfield)
			play.save()

			getfield = startplayer(field=st.stackfield, player1=playername)
			getfield.save()

			context = {'myplay' : play, 'field' : getfield}
			while(startplayer.play==1):
				wait=0
			return render(request, 'start/selectcharacter.html',context)
		elif(startplayer.play==1):
			startplayer.play+=1

			playername = request.POST["playstart"]
			play = player(mynum=playername, field=st.stackfield)
			play.save()

			getfield = startplayer.objects.get(field=st.stackfield)
			getfield.player2=playername
			getfield.save()

			context = {'myplay' : play, 'field' : getfield}
			return render(request, 'start/selectcharacter.html',context)
		else:
			startplayer.play=1
			st.stackfield+=1

			playername = request.POST["playstart"]
			play = player(mynum=playername, field=st.stackfield)
			play.save()

			getfield = startplayer(field=st.stackfield, player1=playername)
			getfield.save()

			context = {'myplay' : play, 'field' : getfield}

			while(startplayer.play==1):
				wait=0
			return render(request, 'start/selectcharacter.html',context)



def selectcardis(request):
	return render(request, 'start/selectcardis.html')

def selectcardbi(request):
	return render(request, 'start/selectcardbi.html')

def selectcardpz(request):
	return render(request, 'start/selectcardpz.html')

class st:
    stackplayer=0
    stackfield=0
    str=""