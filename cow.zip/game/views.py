from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
	a=Foo
	context = {'player' : a}
	
	return render(request, 'start/startscreen.html',context)	  
	
def selectcharacter(request):
	return render(request, 'start/selectcharacter.html')

def selectcardis(request):
	return render(request, 'start/selectcardis.html')

def selectcardbi(request):
	return render(request, 'start/selectcardbi.html')

def selectcardpz(request):
	return render(request, 'start/selectcardpz.html')

class Foo:
    stackplayer=+1
