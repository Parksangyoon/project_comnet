from django.conf.urls import url
from . import views


urlpatterns = [
  url(r'^$', views.goto_game),
  url(r'^Loading/$', views.goto_Loading),
  url(r'^HowtoGame/$', views.goto_HowtoGame),
  url(r'^Editor/$', views.goto_Editor),
  url(r'^Select_Character/(?P<playnum>.+)$', views.goto_Select_Character),
  url(r'^SelectCard_Izreal/$', views.goto_SelectCard_Izreal),
  url(r'^SelectCard_Xvii/$', views.goto_SelectCard_Xvii),
  url(r'^SelectCard_Piz/$', views.goto_SelectCard_Piz),
  url(r'^PlayScreen/(?P<locnum>.+)/$', views.goto_PlayScreen),
  url(r'^Loopplay/(?P<locnum>.+)/$', views.Loop_play)
]
