from django.shortcuts import render
from django.http import HttpResponse
from .Gamelib import *
from .models import player

# Create your views here.



def index(request):
	player.Mynum = control.P_num
	control.P_num = control.P_num + 1
	return render(request,'screen/index.html') #context를 넘겨준다.

class control:
	P_num = 1