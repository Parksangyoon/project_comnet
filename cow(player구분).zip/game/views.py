from django.shortcuts import render
from django.http import HttpResponse

from .models import HandleVariable
# Create your views here.

def index(request):
   
	while(True):
	
		if(HandleVariable.FirstOrSecond ==0):

			HandleVariable.FirstOrSecond+=1
			
			context = {'Playernum':'player1'}

			while(HandleVariable.FirstOrSecond==1):
				fuck=0
				
			return render(request, 'start/startscreen.html', context) #player1

		elif(HandleVariable.FirstOrSecond ==1):

			HandleVariable.FirstOrSecond+=1

			context = {'Playernum':'player2'}

			return render(request, 'start/startscreen.html', context) #player2

		else:

			HandleVariable.FirstOrSecond = 0





def selectcharacter(request):


	return render(request, 'start/selectcharacter.html')

def selectcard(request):

	player(Typesave.Playernum,)
	
	return render(request, 'start/selectcard.html')
