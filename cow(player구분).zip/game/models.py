from django.db import models

class HandleVariable(models.Model):


	FirstOrSecond = 0    
