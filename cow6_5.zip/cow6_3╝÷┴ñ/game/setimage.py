from .Gameplaylib import Client

def Setimage(MYLOC):							#플레이어 데이터를 보고 html에 그릴 image를 setting 해준다.
	location=Client.Data[MYLOC]['imloc']

	if(MYLOC < Client.Data[MYLOC]['enemyloc']):					#player1의 이미지들을 구성 

		if((Client.Data[MYLOC]['character'] == 1) and (Client.Data[MYLOC]['Readcard'] ==1)): #카드 골랐을 때만 셋팅 	
																#이즈리얼을 선택 하였을 경우 html에 그릴 image를 설정한다.
			Client.image[location]['character1'] ="game/iscard.jpg"
			Client.image[location]['firstcard1'] = imagelist.Izreal[int(Client.Data[MYLOC]['CardSelect'][0])-1]
			Client.image[location]['secondcard1'] = imagelist.Izreal[int(Client.Data[MYLOC]['CardSelect'][1])-1]
			Client.image[location]['thirdcard1'] = imagelist.Izreal[int(Client.Data[MYLOC]['CardSelect'][2])-1]
														
		elif((Client.Data[MYLOC]['character'] == 2) and (Client.Data[MYLOC]['Readcard'] ==1)):				
																	#바이를 선택 하였을 경우 html에 그릴 image를 설정한다.
			Client.image[location]['character1'] ="game/bicard.jpg"
			Client.image[location]['firstcard1'] = imagelist.Xvii[int(Client.Data[MYLOC]['CardSelect'][0])-1]
			Client.image[location]['secondcard1'] = imagelist.Xvii[int(Client.Data[MYLOC]['CardSelect'][1])-1]
			Client.image[location]['thirdcard1'] = imagelist.Xvii[int(Client.Data[MYLOC]['CardSelect'][2])-1]

		elif((Client.Data[MYLOC]['character'] == 3) and (Client.Data[MYLOC]['Readcard'] ==1)):				
																	#피즈를 선택 하였을 경우 html에 그릴 image를 설정한다.
			Client.image[location]['character1'] ="game/pzcard.jpg"
			Client.image[location]['firstcard1'] = imagelist.Piz[int(Client.Data[MYLOC]['CardSelect'][0])-1]
			Client.image[location]['secondcard1'] = imagelist.Piz[int(Client.Data[MYLOC]['CardSelect'][1])-1]
			Client.image[location]['thirdcard1'] = imagelist.Piz[int(Client.Data[MYLOC]['CardSelect'][2])-1]
		Client.image[location]['HP1']=Client.Data[MYLOC]['HP']		#그외에 들어갈 html을 그릴 값들을 설정
		Client.image[location]['MP1']=Client.Data[MYLOC]['MP']
		Client.image[location]['Position_x1']=Client.Data[MYLOC]['Position'][0]+1
		Client.image[location]['Position_y1']=Client.Data[MYLOC]['Position'][1]+1
		Client.image[location]['check'] +=1						#player1의 이미지가 구성되면 check를 1 올린다.

	else:														#player2의 이미지들을 구성 	

		if((Client.Data[MYLOC]['character'] == 1) and (Client.Data[MYLOC]['Readcard'] ==1)):				
																 #이즈리얼을 선택 하였을 경우 html에 그릴 image를 설정한다.
			Client.image[location]['character2'] ="game/iscard.jpg"
			Client.image[location]['firstcard2'] = imagelist.Izreal[int(Client.Data[MYLOC]['CardSelect'][0])-1]
			Client.image[location]['secondcard2'] = imagelist.Izreal[int(Client.Data[MYLOC]['CardSelect'][1])-1]
			Client.image[location]['thirdcard2'] = imagelist.Izreal[int(Client.Data[MYLOC]['CardSelect'][2])-1]

		elif((Client.Data[MYLOC]['character'] == 2) and (Client.Data[MYLOC]['Readcard'] ==1)):			
																	#바이를 선택 하였을 경우 html에 그릴 image를 설정한다.
			Client.image[location]['character2'] ="game/bicard.jpg"
			Client.image[location]['firstcard2'] = imagelist.Xvii[int(Client.Data[MYLOC]['CardSelect'][0])-1]
			Client.image[location]['secondcard2'] = imagelist.Xvii[int(Client.Data[MYLOC]['CardSelect'][1])-1]
			Client.image[location]['thirdcard2'] = imagelist.Xvii[int(Client.Data[MYLOC]['CardSelect'][2])-1]

		elif((Client.Data[MYLOC]['character'] == 3) and (Client.Data[MYLOC]['Readcard'] ==1)):				
																	#피즈를 선택 하였을 경우 html에 그릴 image를 설정한다.
			Client.image[location]['character2'] ="game/pzcard.jpg"
			Client.image[location]['firstcard2'] = imagelist.Piz[int(Client.Data[MYLOC]['CardSelect'][0])-1]
			Client.image[location]['secondcard2'] = imagelist.Piz[int(Client.Data[MYLOC]['CardSelect'][1])-1]
			Client.image[location]['thirdcard2'] = imagelist.Piz[int(Client.Data[MYLOC]['CardSelect'][2])-1]
		Client.image[location]['HP2']=Client.Data[MYLOC]['HP']		#그외에 들어갈 html을 그릴 값들을 설정
		Client.image[location]['MP2']=Client.Data[MYLOC]['MP']
		Client.image[location]['Position_x2']=Client.Data[MYLOC]['Position'][0]+1
		Client.image[location]['Position_y2']=Client.Data[MYLOC]['Position'][1]+1
		Client.image[location]['check'] +=1						#player2의 이미지가 구성되면 check를 1 올린다.
	while(not ((Client.image[location]['check']%2)==0)):	#check를 이용해 두 player의 이미지가 구성된것을 확인 후 넘어감  
		pass
	return Client.image[location]

class imagelist:													#각 캐릭터에 속한 image 리스트 
	
	Izreal=["game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg",		#이즈
		   "game/izat1.jpg","game/izat2.jpg","game/izat3.jpg","game/izat4.jpg","game/izat5.jpg"]

	Xvii=["game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg",			#바이
		   "game/Xviiat1.jpg","game/Xviiat2.jpg","game/Xviiat3.jpg","game/Xviiat4.jpg","game/Xviiat5.jpg"]

	Piz=["game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg",			#피즈
		   "game/Pizat1.jpg","game/Pizat2.jpg","game/Pizat3.jpg","game/Pizat4.jpg","game/Pizat5.jpg"]