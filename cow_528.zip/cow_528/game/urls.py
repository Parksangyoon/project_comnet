from django.conf.urls import url
from . import views


urlpatterns = [
  url(r'^$', views.goto_index),
  url(r'^HeroSelect/$', views.goto_HeroSelect),
  url(r'^select/$', views.goto_CardSelectRoom),
  #url(r'^selectcardbi/$', views.selectcardbi),
  #url(r'^selectcardpz/$', views.selectcardpz),
   #url(r'^playscreen/(?P<num>.+)/$', views.playscreen)
]

