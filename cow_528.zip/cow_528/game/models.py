from django.db import models
from .SkillList import SkillList
# Create your models here.
class player:
    def __init__ (self):
        hp=100
        mp=100
        Position = [0, 0]
        Skill_A = [1]
        Skill_B = [1]
        Skill_C = [1]
        Skill_D = [1]
        CardSelection = [0, 0, 0]
        State_data = 0
        Mynum = 0
        Hero = 0
            
    def SelectHero(self):   
        if(self.Hero == 1):     # n번 hero를 골랐다면 Transport_Skill_Hero(n)함수가 실행되도록 한다.
            Transport_Skill_Hero1 (self, SkillList) #각 hero마다 가지고있는 skill의 종류가 다르다.
        elif(self.Hero == 2):
            Transport_Skill_Hero2 (self, SkillList)
        elif(self.Hero == 3):
            Transport_Skill_Hero3 (self, SkillList)


    def Transport_Skill_Hero1 (self, SkillList):  # Hero 1이 가지고 있는 스킬을 0,3,6,7번으로 지정한다.
        self.Skill_A = SkillList.Skill[0]
        self.Skill_B = SkillList.Skill[1]
        self.Skill_C = SkillList.Skill[2]
        self.Skill_D = SkillList.Skill[3]

    def Transport_Skill_Hero2 (self, SkillList):  # Hero 1이 가지고 있는 스킬을 0,2,5,8번으로 지정한다.
        self.Skill_A = SkillList.Skill[1]
        self.Skill_B = SkillList.Skill[2]
        self.Skill_C = SkillList.Skill[5]
        self.Skill_D = SkillList.Skill[8]

    def Transport_Skill_Hero3 (self, SkillList):  # Hero 1이 가지고 있는 스킬을 0,1,4,7번으로 지정한다.
        self.Skill_A = SkillList.Skill[2]
        self.Skill_B = SkillList.Skill[1]
        self.Skill_C = SkillList.Skill[4]
        self.Skill_D = SkillList.Skill[7]
