from django.shortcuts import render
from django.http import HttpResponse
from .Gamelib import *
from .models import player

# Create your views here.


class control:
	P_num = 1
	
def goto_index(request):
	player.Mynum = control.P_num
	control.P_num = control.P_num + 1
	return render(request,'Screen/index.html') #context를 넘겨준다.

def goto_HeroSelect(request):
	return render(request,'Screen/HeroSelect.html') #context를 넘겨준다.


	## 1. 내가 특정 카드[1,2,3]이 인덱싱 되어 있는 것을 선택하면 선택 값에 따라서 인자가 전달

