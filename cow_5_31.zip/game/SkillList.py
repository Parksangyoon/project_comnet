class SkillBook:
    
    damage=[10, 10 ,20 ,20 ,30 ,30 ,40 ,40 ,50 ,50]
    UsingMP=[10, 10, 20, 20, 30, 30, 40, 40, 50, 50]
    
    attackrange = []

    attackrange = [
    [[-1,1],[0,1],[1,1],[-1,0],[0,0],[0,1]],                        #Skill[0]   789456  <-숫자 키패드의 모양을 통해 공격범위를 표현한 것
    [[-1,0],[0,0],[0,1],[-1,-1],[0,-1],[1,-1]],                     #Skill[1]   456123
    [[-1,1],[0,1],[-1,0],[0,0],[-1,-1],[0,-1]],                     #Skill[2]   784512
    [[0,1],[1,1],[0,0],[0,1],[0,-1],[1,-1]],                        #Skill[3]   895623
    [[-1,1],[1,1],[0,0],[-1,-1],[1,-1]],                            #Skill[4]   79513
    [[0,1],[-1,0],[0,0],[0,1],[0,-1]],                              #Skill[5]   84562
    [[0,0],[-1,-1],[0,-1],[1,-1]],                                  #Skill[6]   5123
    [[-1,1],[0,1],[1,1],[0,0]],                                     #Skill[7]   7895
    [[-1,1],[0,1],[1,1],[-1,0],[0,0],[0,1],[-1,-1],[0,-1],[1,-1]],  #Skill[8]   789456123 
    [[0,0],[1,1],[0,1]]                                             #Skill[9]   569
    ]                        
    Skill=  [[attackrange[0],damage[0],UsingMP[0]],[attackrange[1],damage[1],UsingMP[1]],[attackrange[2],damage[2],UsingMP[2]],
            [attackrange[3],damage[3],UsingMP[3]],[attackrange[4],damage[4],UsingMP[4]],[attackrange[5],damage[5],UsingMP[5]],
            [attackrange[6],damage[6],UsingMP[6]],[attackrange[7],damage[7],UsingMP[7]],[attackrange[8],damage[8],UsingMP[8]],
            [attackrange[9],damage[9],UsingMP[9]]]
        
    