from .Gameplaylib import Client

def setimage(location):							#플레이어 데이터를 보고 html에 그릴 image를 setting 해준다.
	if(Client.Data[location]['character'] == 1):				 #이즈리얼을 선택 하였을 경우 html에 그릴 image를 설정한다.
		Client.image[location]['character'] ="game/iscard.jpg"
		Client.image[location]['firstcard'] = imagelist.Izreal[int(Client.Data[location]['CardSelect'][0])-1]
		Client.image[location]['secondcard'] = imagelist.Izreal[int(Client.Data[location]['CardSelect'][1])-1]
		Client.image[location]['thirdcard'] = imagelist.Izreal[int(Client.Data[location]['CardSelect'][2])-1]

	elif(Client.Data[location]['character'] == 2):				#바이를 선택 하였을 경우 html에 그릴 image를 설정한다.
		Client.image[location]['character'] ="game/bicard.jpg"
		Client.image[location]['firstcard'] = imagelist.Xvii[int(Client.Data[location]['CardSelect'][0])-1]
		Client.image[location]['secondcard'] = imagelist.Xvii[int(Client.Data[location]['CardSelect'][1])-1]
		Client.image[location]['thirdcard'] = imagelist.Xvii[int(Client.Data[location]['CardSelect'][2])-1]

	elif(Client.Data[location]['character'] == 3):				#피즈를 선택 하였을 경우 html에 그릴 image를 설정한다.
		Client.image[location]['character'] ="game/pzcard.jpg"
		Client.image[location]['firstcard'] = imagelist.Piz[int(Client.Data[location]['CardSelect'][0])-1]
		Client.image[location]['secondcard'] = imagelist.Piz[int(Client.Data[location]['CardSelect'][1])-1]
		Client.image[location]['thirdcard'] = imagelist.Piz[int(Client.Data[location]['CardSelect'][2])-1]

	Client.image[location]['HP']=Client.Data[location]['HP']		#그외에 들어갈 html을 그릴 값들을 설정
	Client.image[location]['MP']=Client.Data[location]['MP']
	Client.image[location]['Position_x']=Client.Data[location]['Position'][0]
	Client.image[location]['Position_y']=Client.Data[location]['Position'][1]
	Client.image[location]['myloc']=Client.Data[location]['myloc']
	return Client.image[location]

class imagelist:													#각 캐릭터에 속한 image 리스트 

	
	Izreal=["game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg",		#이즈
		   "game/izat1.jpg","game/izat2.jpg","game/izat3.jpg","game/izat4.jpg","game/izat5.jpg"]

	Xvii=["game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg",			#바이
		   "game/Xviiat1.jpg","game/Xviiat2.jpg","game/Xviiat3.jpg","game/Xviiat4.jpg","game/Xviiat5.jpg"]

	Piz=["game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg","game/move1.jpg",			#피즈
		   "game/Pizat1.jpg","game/Pizat2.jpg","game/Pizat3.jpg","game/Pizat4.jpg","game/Pizat5.jpg"]