from django.shortcuts import render
from django.http import HttpResponse

from .models import player1, player2
# Create your views here.

def index(request): 
	start.start+=1
	if(start.start ==1):
		start.str="player{}".format(start.start) 
		context = {'num' : start} 
		return render(request, 'start/startscreen.html',context)
	elif(start.start ==2):
		start.str="player{}".format(start.start) 
		context = {'num' : start} 
		return render(request, 'start/startscreen.html',context)
	else:
		return
	
def selectcharacter(request):
	check = request.POST["playstart"]
	start.wait+=1
	if(check == "player1"):
		context={'num' : check}
		while(start.wait==1):
			wait=0
		return render(request, 'start/selectcharacter.html',context)

	elif(check == "player2"):
		context={'num' : check}
		return render(request, 'start/selectcharacter.html',context)

def selectcardis(request):
	take = request.POST["play"]
	if(take == "player1"):
		player1.card=1
		context={'num' : take}
		return render(request, 'start/selectcardis.html',context)

	elif(take == "player2"):
		player2.card=1
		context={'num' : take}
		return render(request, 'start/selectcardis.html',context)

def selectcardbi(request):
	check = request.POST["play"]
	if(check == "player1"):
		player1.card=2
		context={'num' : check}
		return render(request, 'start/selectcardbi.html',context)

	elif(check == "player2"):
		player2.card=2
		context={'num' : check}
		return render(request, 'start/selectcardbi.html',context)

def selectcardpz(request):
	check = request.POST["play"]
	if(check == "player1"):
		player1.card=3
		context={'num' : check}
		return render(request, 'start/selectcardpz.html',context)

	elif(check == "player2"):
		player2.card=3
		context={'num' : check}
		return render(request, 'start/selectcardpz.html',context)

class start:
	wait=0
	end=0
	start=0
	str=""