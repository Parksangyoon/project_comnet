from django.db import models

# Create your models here.
class player1:
    hp=100
    card=0
    
class player2:
    hp=100
    mp=100
