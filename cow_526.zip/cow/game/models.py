from django.db import models
from .SkillList import SkillList
# Create your models here.
class player1:
    hp=100
    mp=100
    Hero=0	#선택한 캐릭터의 id(is = 1 bi = 2 pz = 3)
    Position = [0, 0]
    Skill_A = [1]
    Skill_B = [1]
    Skill_C = [1]
    Skill_D = [1]
    CardSelection = [0, 0, 0]

    def getSkillandPos (): # 처음 생성시 데이터를 입력해주는 함수
        
        player1.Position = [0, 1] # player1은 (0,1)위치에서 시작하도록 한다.
        
       
        if(player1.Hero == 1):     # n번 hero를 골랐다면 Transport_Skill_Hero(n)함수가 실행되도록 한다.
            Transport_Skill_Hero1 (player1, SkillList) #각 hero마다 가지고있는 skill의 종류가 다르다.
        elif(player1.Hero == 2):
            Transport_Skill_Hero2 (player1, SkillList)
        elif(player1.Hero == 3):
            Transport_Skill_Hero3 (player1, SkillList)
    
class player2:
    hp=100
    mp=100
    Hero=0
    Position = [0, 0]
    Skill_A = [1]
    Skill_B = [1]
    Skill_C = [1]
    Skill_D = [1]
    CardSelection = [0, 0, 0]

    def getSkillandPos ():        # 처음 생성시 데이터를 입력해주는 함수
        
        player2.Position = [4, 2] # player2는 (4,2)위치에서 시작하도록 한다.
       
        if(player2.Hero == 1):     # n번 hero를 골랐다면 Transport_Skill_Hero(n)함수가 실행되도록 한다.
            Transport_Skill_Hero1 (player2, SkillList) #각 hero마다 가지고있는 skill의 종류가 다르다.
        elif(player2.Hero == 2):
            Transport_Skill_Hero2 (player2, SkillList)
        elif(player2.Hero == 3):
            Transport_Skill_Hero3 (player2, SkillList)
    
def Transport_Skill_Hero1 (Player, SkillList):  # Hero 1이 가지고 있는 스킬을 0,3,6,7번으로 지정한다.
    Player.Skill_A = SkillList.Skill[0]
    Player.Skill_B = SkillList.Skill[1]
    Player.Skill_C = SkillList.Skill[2]
    Player.Skill_D = SkillList.Skill[3]

def Transport_Skill_Hero2 (Player, SkillList):  # Hero 1이 가지고 있는 스킬을 0,2,5,8번으로 지정한다.
    Player.Skill_A = SkillList.Skill[1]
    Player.Skill_B = SkillList.Skill[2]
    Player.Skill_C = SkillList.Skill[5]
    Player.Skill_D = SkillList.Skill[8]
def Transport_Skill_Hero3 (Player, SkillList):  # Hero 1이 가지고 있는 스킬을 0,1,4,7번으로 지정한다.
    Player.Skill_A = SkillList.Skill[2]
    Player.Skill_B = SkillList.Skill[1]
    Player.Skill_C = SkillList.Skill[4]
    Player.Skill_D = SkillList.Skill[7]