from django.shortcuts import render
from django.http import HttpResponse

from .models import player1, player2
# Create your views here.

def index(request): 
	givenum =st.stackplayer+0			#들어오는 순서데로 번호를 부여해 준다.
	st.stackplayer+=1					
	context = {'num' : givenum}			#부여된 번호 context에 넣는다.
	return render(request, 'start/startscreen.html',context) #context를 넘겨준다.
	
def selectcharacter(request):
	st.joinnum+=1												#두명씩 게임을 시작할 수 있도록 하는 컨트롤 변수
	if(st.joinnum==2):											#플레이어2가 들어왔을 때 
		mynum = int(request.POST['playstart'])						#부여된 플레이어 번호를 가져온다.

		myloc=int(st.location+1)										#플레이어 2의 data가 저장될 위치
		enemyloc=int(st.location+0)									#플레이어 1의 data가 저장되어있는 위치
		st.location+=2											#두 플레이어 이외 다음 두플레이어가 사용할 위치 설정 

		enemy=int(st.player[enemyloc]['playnum'])				#플레이어1의 번호를 가져온다.
		st.player[enemyloc]['enemynum']=mynum				#플레이어1의 data의 enemynum에 자신의 번호를 넣어준다.

		player2={'playnum':mynum, 'enemynum':enemy, 'myloc':myloc, 'enemyloc':enemyloc, 
		'select':0} 											#플레이어2의 data

		st.player.append(player2)								#플레이어 2의 data가 저장될 위치에 저장 

		data ={'num' : mynum, 'data' :myloc}			#자신의 플레이어 번호와, data를 넘겨준다.

		return render(request, 'start/selectcharacter.html', data)
	else:														#플레이어 1이 들어왔을 때(2명중 처음 들어온 플레이어)
		mynum = int(request.POST['playstart'])						#부여된 플레이어 번호를 가져온다.

		st.joinnum=1											

		myloc=int(st.location+0)										#플레이어 1의 data가 저장될 위치
		enemyloc=int(st.location+1)									#플레이어 2의 data가 저장될 위치

		player1={'playnum':mynum, 'enemynum':"unkown", 'myloc':myloc, 'enemyloc':enemyloc,
		'select':0} 											#플레이어1의 data 설정
																#플레이어1과 상대될 플레이어2를 아직 모르므로 "unkown"
		st.player.append(player1)								#플레이어1 data를 추가

		data ={'num' : mynum, 'data' :myloc}			#자신의 플레이어 번호와, data를 넘겨준다

		while(st.joinnum==1):									#플레이어2를 기다린다.
			pass
		return render(request, 'start/selectcharacter.html', data)

def selectcardis(request):
	myloc = int(request.POST['play'])								#플레이어의 데이터를 받아온다.
	st.player[myloc]['character']=1						#플레이어의 데이터에 character 를 추가한다.(선택 피즈)
	data={'num' : myloc}
	return render(request, 'start/selectcardis.html', data)

def selectcardbi(request):
	myloc = int(request.POST['play'])								#플레이어의 데이터를 받아온다.
	st.player[myloc]['character']=2						#플레이어의 데이터에 character 를 추가한다.(선택 바이)
	data={'num' : myloc}
	return render(request, 'start/selectcardbi.html', data)

def selectcardpz(request):
	myloc = int(request.POST['play'])								#플레이어의 데이터를 받아온다.
	st.player[myloc]['character']=3						#플레이어의 데이터에 character 를 추가한다.(선택 피즈)
	data={'num' : myloc}
	return render(request, 'start/selectcardpz.html', data)

def playscreen(request, num):
	myloc = int(num)										#플레이어의 데이터를 받아온다.
	first=request.POST['firstcard']					#선택한 첫번째 카드를 가져온다.
	second=request.POST['secondcard']					#선택한 두번째 카드를 가져온다.
	third=request.POST['thirdcard']					#선택한 세번째 카드를 가져온다.

	if(not first.isdigit() or not second.isdigit() or not third.isdigit()):		#카드선택에 숫자 이외의 값을 넣었을 경우 다시 선택
		data={'num' : myloc}
		if(st.player[myloc]['character']==1):
			return render(request, 'start/selectcardis.html', data)
		elif(st.player[myloc]['character']==2):
			return render(request, 'start/selectcardbi.html', data)
		else:
			return render(request, 'start/selectcardpz.html', data)
	if(not (int(first)>0 and int(first)<9) or not (int(second)>0 and int(second)<9)	or not (int(third)>0 and int(third)<9)):
																			#카드값이 범위에 없을 경우 다시 선택 
		data={'num' : myloc}
		if(st.player[myloc]['character']==1):
			return render(request, 'start/selectcardis.html', data)
		elif(st.player[myloc]['character']==2):
			return render(request, 'start/selectcardbi.html', data)
		else:
			return render(request, 'start/selectcardpz.html', data)

	st.player[myloc]['first']=int(first)						#첫번째 카드를 플레이어 데이터에 저장 
	st.player[myloc]['second']=int(second)					#두번째 카드를 플레이어 데이터에 저장
	st.player[myloc]['third']=int(third)						#세번째 카드를 플레이어 데이터에 저장 
	st.player[myloc]['select']=1									#선택이 끝남을 표시 
	data={'num' : myloc, 'data':st.player[myloc]}		
	enemyloc=int(st.player[myloc]['enemyloc'])					#상대 데이터 위치를 가져온다.
	while(st.player[enemyloc]['select'] ==0):				#상대가 카드를 선택을 완료 할 때까지 기다린다.
		pass

	return render(request, 'start/playscreen.html', data)
class st:
	player =[]
	stackplayer=0
	joinnum=0
	location=0
	selectok=0
	str=""