from django.shortcuts import render
from django.http import HttpResponse
from .Gamelib import *
from .models import player

# Create your views here.

class control:
	P_num = 1
	Move_to_Room = 0

def goto_index(request):
	player.Mynum = control.P_num  #플레이어 구분하기.
	player.SetPosition()
	control.P_num = control.P_num + 1
	control.Move_to_Room = control.Move_to_Room + 1 
	return render(request,'Screen/index.html') #초기 화면'index.html'으로 넘겨준다.

def goto_HeroSelect(request):
	return render(request, 'Screen/HeroSelect.html')

def goto_CardSelectRoom(request):
	Herotype = int(request.POST('HeroSelect'))
	player.Hero = Herotype
	player.SelectHero()
	while True:
		if(control.Move_to_Room == 2):
			control.Move_to_Room = 0
			break
		else:
			pass
	return render(request, 'Screen/CardselectRoom.html')

def goto_BattleRoom(request):

	Firstcard = int(request.POST('1st_card'))
	Secondcard = int(request.POST('2nd_card'))
	Thirdcard = int(request.POST('3rd_card'))
	player.CardSelection = [Firstcard, Secondcard, Thirdcard]
	return render(request, 'Screen/BattleRoom.html')

