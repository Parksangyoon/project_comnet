from .SkillList import SkillBook
class Client:
    Data = []
    image =[]
    Field = []

class Controll:
    stackplayer=0
    joinnum=0
    location=0
    selectok=0
    Fieldloc=0
    imloc=0
    adad=0
    join=0
    
def player_Setting(mynum, enemynum, myloc, enemyloc, position):
    player={'playnum':mynum, 
             'enemynum':enemynum, 
             'myloc':myloc,
             'enemyloc':enemyloc, 
             'Position':position, 
             'HP' :100, 
             'MP' :100, 
             'Readcard':0,
             'Prior':0,
             'imloc':0,
             'fieldloc':Controll.Fieldloc
           }
    return player
def stack_Setting():
    StackList={'stack1':0,
                'stack2':0,
                'stack3':0
            }
    return StackList

def Izreal_Setting(player):
    player['character'] = 1                     #플레이어의 데이터에 character 를 추가한다.(선택 이즈)
    player['Skill_A'] = SkillBook.Skill[5]
    player['Skill_B'] = SkillBook.Skill[0]
    player['Skill_C'] = SkillBook.Skill[3]
    player['Skill_D'] = SkillBook.Skill[1]

def Piz_Setting(player):
    player['character'] = 3                     #플레이어의 데이터에 character 를 추가한다.(선택 피즈)
    player['Skill_A'] = SkillBook.Skill[1]
    player['Skill_B'] = SkillBook.Skill[4]
    player['Skill_C'] = SkillBook.Skill[8]
    player['Skill_D'] = SkillBook.Skill[6]
def Xvii_Setting(player):
    player['character'] = 2                     #플레이어의 데이터에 character 를 추가한다.(선택 바이)
    player['Skill_A'] = SkillBook.Skill[0]
    player['Skill_B'] = SkillBook.Skill[5] 
    player['Skill_C'] = SkillBook.Skill[9]
    player['Skill_D'] = SkillBook.Skill[7]

def PatternPlaying(player1,player2,cardnumber):
    cardnumber = int(cardnumber)

    if(cardnumber>=6 and cardnumber<=9 ):
        Client.Field[player1['fieldloc']]['stack3']+=1
        #Controll.adad+=1
        while(Controll.adad==1):
            pass
    else:
        pass
    if(0<cardnumber and cardnumber<6):  #이동이나 마나 카드를 실행했더라도 스택을 1올려줌
        
        cardmove(cardnumber, player1['Position'])
        #Client.FieldVariable[player1['fieldloc']]+=1
        #Controll.adad+=1
        Client.Field[player1['fieldloc']]['stack3']+=1
    elif(cardnumber==10):

        if(player1['MP']<=80):
            player1['MP'] += 20
        else:
            player1['MP'] = 100
        #Client.FieldVariable[player1['fieldloc']]+=1
        #Controll.adad+=1
        Client.Field[player1['fieldloc']]['stack3']+=1
    else:

        if(cardnumber == 6):
            cardskill(player1, player2, player1['Skill_A'])

        elif(cardnumber == 7):
            cardskill(player1, player2, player1['Skill_B'])

        elif(cardnumber == 8):
            cardskill(player1, player2, player1['Skill_C'])

        elif(cardnumber == 9):
            cardskill(player1, player2, player1['Skill_D'])
        
    #if(Client.FieldVariable[player1['fieldloc']]==2):
    #    Client.FieldVariable[player1['fieldloc']]=0

    #if(Controll.adad==2):
     #   Controll.adad=0
    if(Client.Field[player1['fieldloc']]['stack3']==2):
        Client.Field[player1['fieldloc']]['stack3']=0
    
    

     #모든 사용자가 카드사용을 마쳤으므로 default로 바꿔준다.


def cardmove (cardnum,myPOS):        #선택한 카드 정보, 플레이어의 좌표
         
    Move =  [[0,0],[0,-1],[-1,0],[0,1],[1,0]]   #  0- 1↑ 2← 3↓ 4→ 

    myPOS[0] = myPOS[0] + Move[cardnum-1][0]
    myPOS[1] = myPOS[1] + Move[cardnum-1][1]

    if(myPOS[0]<1):
        myPOS[0]+=1
    elif(myPOS[0]>5):
        myPOS[0]-=1

    if(myPOS[1]<1):
        myPOS[1]+=1
    elif(myPOS[1]>4):
        myPOS[1]-=1

def cardskill (player1,player2,skill):

    skillrange = skill[0] 
    skilldamage = skill[1]
    skillMP = skill[2]
    is_hit = False

    for i in range(len(skillrange)) :
                
        if(player2['Position']==[player1['Position'][0] + skillrange[i][0], player1['Position'][1] + skillrange[i][1]]):
            is_hit = True

    if(is_hit==True):
        player2['HP'] = player2['HP'] - skilldamage

    player1['MP'] = player1['MP'] - skillMP

def getskillmana(player,num):

    if(num==6):
        return player['Skill_A'][2]
    elif(num==7):
        return player['Skill_B'][2]
    elif(num==8):
        return player['Skill_C'][2]
    elif(num==9):
        return player['Skill_D'][2]
    else:
        return 0
'''
def PatternPlaying (player1,player2,cardnumber):   # 선택한 카드번호에 따라 행동하게 하는 함수
    if(cardnumber == 0):    # stay 카드(그자리에 정지)
        player1['Position'][0] = player1['Position'][0] + 0 
        player1['Position'][1] = player1['Position'][1] + 0
    elif(cardnumber == 1):  # up 카드 (위로 한칸 이동)
        player1['Position'][0] = player1['Position'][0] + 0
        player1['Position'][1] = player1['Position'][1] + 1
    elif(cardnumber == 2):  # down 카드 (아래로 한칸 이동)
        player1['Position'][0] = player1['Position'][0] + 0
        player1['Position'][1] = player1['Position'][1] - 1
    elif(cardnumber == 3):  # left 카드 (왼쪽으로 한칸 이동)
        player1['Position'][0] = player1['Position'][0] + 1
        player1['Position'][1] = player1['Position'][1] + 0
    elif(cardnumber == 4):  # right 카드 (오른쪽으로 한칸 이동)
        player1['Position'][0] = player1['Position'][0] - 1
        player1['Position'][1] = player1['Position'][1] + 0
    elif(cardnumber == 5):  # skill_A 발동
        Act_Skill_A(player1,player2)
    elif(cardnumber == 6):  # skill_B 발동
        Act_Skill_B(player1,player2)
    elif(cardnumber == 7):  # skill_C 발동
        Act_Skill_C(player1,player2)
    elif(cardnumber == 8):  # skill_D 발동
        Act_Skill_D(player1,player2)

def Act_Skill_A(player1,player2): #Skill_A가 발동하였을 경우 실행한다.
    SR = player1['Skill_A'][0] # SR에 공격 범위를 저장한다.
    SD = player1['Skill_A'][1] # SD에 공격 데미지를 저장한다.
    SM = player1['Skill_A'][2] # SM에 소모되는 마력을 저장한다.
    for i in range(len(SR)): # 공격범위에 저장되어있는 좌표 갯수만큼 반복하여 동작한다. 
        pos = SR[i] 
        if(player2['Position'] == [player1['Position'][0] + pos[0], player1['Position'][1] + pos[1]]):
                # 적군의 위치가 현재 skill의 공격범위내에 있다면 
            player2['HP'] = player2['HP'] - SD # 공격 데미지만큼 체력을 깎아준다.
    player1['MP'] = player1['MP'] - SM # 소모된 마력만큼 현재 마력에서 깎아준다. 

def Act_Skill_B(player1,player2): #Skill_B가 발동하였을 경우 실행한다.
    SR = player1['Skill_B'][0] 
    SD = player1['Skill_B'][1] 
    SM = player1['Skill_B'][2]
    for i in range(len(SR)):
        pos = SR[i]
        if(player2['Position'] == [player1['Position'][0] + pos[0], player1['Position'][1] + pos[1]]):
            player2['HP']  = player2['HP'] - SD 
    player1['MP'] = player1['MP'] - SM

def Act_Skill_C(player1,player2): #Skill_C가 발동하였을 경우 실행한다.
    SR = player1['Skill_C'][0]
    SD = player1['Skill_C'][1]
    SM = player1['Skill_C'][2]
    for i in range(len(SR)):
        pos = SR[i]
        if(player2['Position'] == [player1['Position'][0] + pos[0], player1['Position'][1] + pos[1]]):
            player2['HP']  = player2['HP'] - SD 
    player1['MP'] = player1['MP'] - SM    

def Act_Skill_D(player1,player2): #Skill_D가 발동하였을 경우 실행한다.
    SR = player1['Skill_D'][0]
    SD = player1['Skill_D'][1]
    SM = player1['Skill_D'][2]
    for i in range(len(SR)):
        pos = SR[i]
        if(player2['Position'] == [player1['Position'][0] + pos[0], player1['Position'][1] + pos[1]]):
            player2['HP']  = player2['HP'] - SD 
    player1['MP'] = player1['MP'] - SM
    '''

def CardCheck(player,card1, card2, card3):
    
    Check = False
    if( (card1.isdigit()) and (card2.isdigit()) and (card3.isdigit()) ):
        card1 = int(card1)
        card2 = int(card2)
        card3 = int(card3)
        if( (card1 > 0 and card1 < 11) and (card2 > 0 and card2 < 11) and (card3 > 0 and card3 < 11) ):
            if( (card1 != card2) and (card2 != card3) and (card3 != card1) ):
                if( player['MP'] < (getskillmana(player,card1) + getskillmana(player,card2) + getskillmana(player,card3)) ):
                    Check = False
                    return Check
                else:
                    pass
                Check = True
                return Check
            else:
                Check = False
                return Check
        else:
            Check = False
            return Check
    else:
        Check =False
        return Check
'''
def importPrior(player1):
    i = player1['Readcard']
    if(player1['CardSelect'][i] < 6):
        player1['Prior'] = 1
    else:
        player1['Prior'] = 0

def CheckPrior(player1, player2):
    if(player1['Prior'] < player2['Prior']):
        while( player1['Prior'] < player2['Prior'] ):
            pass
    else:
        

def FieldOut_Check(Player):
    Temp_Position=[]
    Temp_Position=Player.Position
    for i in range(len(Player.CardSelection)):
        if(Player.CardSelection[i] < 5):
            if(Player.CardSelection[i] == 1):
                Temp_Position[0] = Temp_Position[0] + 0
                Temp_Position[1] = Temp_Position[1] + 1
            elif(Player.CardSelection[i] == 2):
                Temp_Position[0] = Temp_Position[0] + 0
                Temp_Position[1] = Temp_Position[1] - 1
            elif(Player.CardSelection[i] == 3):
                Temp_Position[0] = Temp_Position[0] + 1
                Temp_Position[1] = Temp_Position[1] + 0
            elif(Player.CardSelection[i] == 4):
                Temp_Position[0] = Temp_Position[0] - 1
                Temp_Position[1] = Temp_Position[1] + 0
        if(Temp_Position[0] < 0 or Temp_Position[0] > 4 or Temp_Position[1] < 0 or Temp_Position[1] > 3):
            print("Your Movement is out of Field ! ! ! Reselect Card !\n")
            return False
        else:
            return True

def Mp_Check(Player):
    Temp_Mp = Player.Mp
    Comulating_Mp = 0
    for i in range(len(Player.CardSelection)):
        if(Player.CardSelection[i] > 4):
            if(Player.CardSelection[i] == 5):
                Comulating_Mp = Comulating_Mp + Player.Skill_A[2]
            elif(Player.CardSelection[i] == 6):
                Comulating_Mp = Comulating_Mp + Player.Skill_B[2]
            elif(Player.CardSelection[i] == 7):
                Comulating_Mp = Comulating_Mp + Player.Skill_C[2]
            elif(Player.CardSelection[i] == 8):
                Comulating_Mp = Comulating_Mp + Player.Skill_D[2]
    if(Temp_Mp < Comulating_Mp):
        print("You have MP overflow ! ! ! Reselect Card !\n")
        return False
    else:
        return True

def Gaming(Player1, Player2):
    while True:
        while True:
            self.CardCounting(Player1)
            x = self.Mp_Check(Player1)
            _x = self.FieldOut_Check(Player1)
            if(x and _x):
                break
        while True:
            self.CardCounting(Player2)
            y = self.Mp_Check(Player2)
            _y = self.FieldOut_Check(Player2)
            if(y and _y):
                break

        for i in range(len(self.Playing)):
            if(Player1.CardSelection[i] < 5 and Player2.CardSelection[i] > 4): 
                Player1.PatternPlaying(Player1.CardSelection[i], Player2)
                Player2.PatternPlaying(Player2.CardSelection[i], Player1)
            elif(Player2.CardSelection[i] < 5 and Player1.CardSelection[i] > 4):
                Player2.PatternPlaying(Player2.CardSelection[i], Player1)
                Player1.PatternPlaying(Player1.CardSelection[i], Player2)
            else:
                Player1.PatternPlaying(Player1.CardSelection[i], Player2)
                Player2.PatternPlaying(Player2.CardSelection[i], Player1)
            print (("[ Player %d ] \n HP : %d \n MP : %d \n   Current Position : (%d, %d) \n") % (1, Player1.Hp, Player1.Mp, Player1.Position[0], Player1.Position[1] ))
            print (("[ Player %d ] \n HP : %d \n MP : %d \n   Current Position : (%d, %d) \n") % (2, Player2.Hp, Player2.Mp, Player2.Position[0], Player2.Position[1] ))


        if(Player1.Hp < 0 or Player2.Hp < 0):
            if(Player1.Hp > 0 and Player2.Hp < 0):
                print(">>> GameOver Player1 WIN ! ! ! <<<\n")
                break
            elif(Player1.Hp < 0 and Player2.Hp > 0):
                print(">>> GameOver Player2 WIN ! ! ! <<<\n")
                break
            elif(Player1.Hp < 0 and Player2.Hp < 0):
                print(">>> Draw ! ! ! <<<\n")
                break   '''