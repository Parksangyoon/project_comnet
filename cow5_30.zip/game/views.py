from django.shortcuts import render
from django.http import HttpResponse
from .models import st
from .Gameplaylib import*
# Create your views here.


def index(request): 
	givenum =st.stackplayer+0			#들어오는 순서데로 번호를 부여해 준다.
	st.stackplayer+=1					
	context = {'num' : givenum}			#부여된 번호 context에 넣는다.
	return render(request, 'start/startscreen.html',context) #context를 넘겨준다.
	
def selectcharacter(request):
	st.joinnum+=1												#두명씩 게임을 시작할 수 있도록 하는 컨트롤 변수
	if(st.joinnum==2):											#플레이어2가 들어왔을 때 
		mynum = int(request.POST['playstart'])						#부여된 플레이어 번호를 가져온다.
		myloc = int(st.location+1)										#플레이어 2의 data가 저장될 위치
		enemyloc = int(st.location+0)									#플레이어 1의 data가 저장되어있는 위치
		st.location += 2											#두 플레이어 이외 다음 두플레이어가 사용할 위치 설정 

		enemynum = int(st.player[enemyloc]['playnum'])				#플레이어1의 번호를 가져온다.
		st.player[enemyloc]['enemynum'] = mynum				#플레이어1의 data의 enemynum에 자신의 번호를 넣어준다.

		player2 = player2_Setting(mynum, enemynum, myloc, enemyloc)  #플레이어2의 data
		st.player.append(player2)								#플레이어 2의 data가 저장될 위치에 저장 

		data = {'num' : mynum, 'data' :myloc}			#자신의 플레이어 번호와, data를 넘겨준다.

		return render(request, 'start/selectcharacter.html', data)
	else:														#플레이어 1이 들어왔을 때(2명중 처음 들어온 플레이어)
		st.joinnum=1	
		mynum = int(request.POST['playstart'])						#부여된 플레이어 번호를 가져온다.										
		myloc = int(st.location+0)										#플레이어 1의 data가 저장될 위치
		enemyloc = int(st.location+1)									#플레이어 2의 data가 저장될 위치

		player1 = player1_Setting(mynum, myloc, enemyloc)   #플레이어1의 data 설정														#플레이어1과 상대될 플레이어2를 아직 모르므로 "unkown"
		st.player.append(player1)								#플레이어1 data를 추가

		data = {'num' : mynum, 'data' :myloc}			#자신의 플레이어 번호와, data를 넘겨준다

		while(st.joinnum==1):									#플레이어2를 기다린다.
			pass
		return render(request, 'start/selectcharacter.html', data)

def selectcardis(request):
	myloc = int(request.POST['play'])								#플레이어의 데이터를 받아온다.
	Izreal_Setting(st.player[myloc])
	data={'num' : myloc}
	return render(request, 'start/selectcardis.html', data)

def selectcardbi(request):
	myloc = int(request.POST['play'])								#플레이어의 데이터를 받아온다.
	Xvii_Setting(st.player[myloc])
	data={'num' : myloc}
	return render(request, 'start/selectcardbi.html', data)

def selectcardpz(request):
	myloc = int(request.POST['play'])								#플레이어의 데이터를 받아온다.
	Piz_Setting(st.player[myloc])
	data={'num' : myloc}
	return render(request, 'start/selectcardpz.html', data)

def playscreen(request, num):

	myloc = int(num)
	enemyloc = st.player[myloc]['enemyloc']

	if(st.player[myloc]['Readcard'] == 0 and st.player[myloc]['HP'] != 0):
		
		st.player[myloc]['Ready'] = 0
		First = request.POST['firstcard']					#선택한 첫번째 카드를 가져온다.
		Second = request.POST['secondcard']					#선택한 두번째 카드를 가져온다.
		Third = request.POST['thirdcard']
		
		if( CardCheck(First, Second, Third) ):
			CardSelect = [First, Second, Third]
		else:
			data = {'num' : myloc}
			if(st.player[myloc]['character']==1):
				return render(request, 'start/selectcardis.html', data)
			elif(st.player[myloc]['character']==2):
				return render(request, 'start/selectcardbi.html', data)
			else:
				return render(request, 'start/selectcardpz.html', data)

		st.player[myloc]['CardSelect']= CardSelect
		st.player[myloc]['Ready'] = 1

		data = st.player[myloc]
		while True:
			if(st.player[enemyloc]['Ready'] == 1):
				return render(request, 'start/playscreen.html', data)
			else:
				pass
	elif(st.player[myloc]['Readcard'] == 1 and st.player[myloc]['HP'] != 0):
		#타이머 추가 요망.
		PatternPlaying(st.player[myloc], st.player[enemyloc], st.player[myloc]['CardSelect'][0])
		st.player[myloc]['Readcard'] = 2
		data = st.player[myloc]
		if(st.player[myloc]['HP'] <= 0, st.player[enemyloc]['HP'] > 0):
			return render(request, 'start/lose.html', data)
		elif(st.player[myloc]['HP'] > 0, st.player[enemyloc]['HP'] <= 0):
			return render(request, 'start/win.html', data)
		elif(st.player[myloc]['HP'] <= 0, st.player[enemyloc]['HP'] <= 0):
			return render(request, 'start/draw.html', data)
		else:
			return render(request, 'start/playscreen.html', data) 

	elif(st.player[myloc]['Readcard'] == 2 and st.player[myloc]['HP'] != 0):
		#타이머 추가 요망.
		PatternPlaying(st.player[myloc], st.player[enemyloc], st.player[myloc]['CardSelect'][1])
		st.player[myloc]['Readcard'] = 3
		data = st.player[myloc]
		if(st.player[myloc]['HP'] <= 0, st.player[enemyloc]['HP'] > 0):
			return render(request, 'start/lose.html', data)
		elif(st.player[myloc]['HP'] > 0, st.player[enemyloc]['HP'] <= 0):
			return render(request, 'start/win.html', data)
		elif(st.player[myloc]['HP'] <= 0, st.player[enemyloc]['HP'] <= 0):
			return render(request, 'start/draw.html', data)
		else:
			return render(request, 'start/playscreen.html', data)  

	elif(st.player[myloc]['Readcard'] == 3 and st.player[myloc]['HP'] != 0):
		#타이머 추가 요망.
		PatternPlaying(st.player[myloc], st.player[enemyloc], st.player[myloc]['CardSelect'][2])
		st.player[myloc]['Readcard'] = 0
		data = st.player[myloc]
		if(st.player[myloc]['HP'] <= 0, st.player[enemyloc]['HP'] > 0):
			return render(request, 'start/lose.html', data)
		elif(st.player[myloc]['HP'] > 0, st.player[enemyloc]['HP'] <= 0):
			return render(request, 'start/win.html', data)
		elif(st.player[myloc]['HP'] <= 0, st.player[enemyloc]['HP'] <= 0):
			return render(request, 'start/draw.html', data)
		else:
			if(st.player[myloc]['character'] == 1):								 #카드 선택 화면으로 넘어감
				return render(request, 'start/selectcardis.html', data)
			elif(st.player[myloc]['character'] == 2):
				return render(request, 'start/selectcardbi.html', data)
			else:
				return render(request, 'start/selectcardpz.html', data)