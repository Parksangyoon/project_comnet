from django.db import models
# Create your models here.
class Client (models.Model):
	Data = []

class Controll (models.Model):
    stackplayer=0
    joinnum=0
    location=0
    selectok=0

