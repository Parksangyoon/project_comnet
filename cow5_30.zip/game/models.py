from django.db import models
# Create your models here.

class st:
    player =[]
    stackplayer=0
    joinnum=0
    location=0
    selectok=0

