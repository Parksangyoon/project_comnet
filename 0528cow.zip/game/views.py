from django.shortcuts import render
from django.http import HttpResponse

from .models import player
# Create your views here.

def index(request):
	player.
def selectcharacter(request):

def selectcardis(request):

def selectcardbi(request):
	
def selectcardpz(request):
	
def playscreen(request, num):



